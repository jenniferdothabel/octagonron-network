# OctagonRon Network — Design Brief

## Three Approaches Considered

1. **Neon Noir** (prob: 0.04) — Cyberpunk dark with neon glow, grid lines, and glitch effects. Energetic but overused.
2. **Obsidian Premium** (prob: 0.07) — Matte black with electric cyan/violet, frosted glass, and particle networks. Exclusive, tech-forward, premium. ← CHOSEN
3. **Liquid Metal** (prob: 0.02) — Chrome and silver gradients on deep navy, metallic reflections. Cold and corporate.

---

## Chosen Approach: Obsidian Premium

### Design Movement
Dark-mode premium tech brand (think Vercel × Stripe × high-end fintech). Confident, minimal, and kinetic.

### Core Principles
1. Depth through layering — matte black base, frosted glass mid-layer, glowing accents on top
2. Motion as meaning — every animation reinforces "connection," "momentum," and "growth"
3. Restraint with impact — generous whitespace, then moments of visual intensity
4. Octagon as identity — the shape appears everywhere: borders, progress indicators, CTA, logo

### Color Philosophy
- **Background:** #080a0f (near-black with blue undertone — not pure black, warmer)
- **Primary Accent:** #00d4ff (electric cyan — energy, technology, clarity)
- **Secondary Accent:** #8b5cf6 (violet — premium, exclusivity, depth)
- **Glass panels:** rgba(255,255,255,0.04) with 1px rgba(255,255,255,0.1) border
- **Text:** #ffffff primary, #94a3b8 secondary
- **Gold (leaderboard):** #fbbf24

### Layout Paradigm
Full-viewport sections with asymmetric content placement. Hero is edge-to-edge canvas. Sections alternate left/right weight. No centered grid monotony.

### Signature Elements
1. **Octagon motif** — clip-path octagons, octagon borders, octagon scroll indicator
2. **Particle network** — glowing nodes connected by animated lines throughout
3. **Frosted glass cards** — backdrop-blur panels with subtle inner glow

### Interaction Philosophy
Every hover, click, and scroll should feel like the interface is alive and aware of the user. Buttons tilt with cursor. Cards lift in 3D. Numbers count up. Cursor leaves electric trail.

### Animation
- Hero canvas: continuous particle network with pulse animations
- Scroll-triggered: sections fade+slide in from below (staggered children)
- Number counters: smooth easing, never instant
- Octagon CTA: expands on cursor proximity, emits pulse on click
- Timeline: nodes light up sequentially on scroll
- Leaderboard: gold glow pulses on first place

### Typography System
- **Display:** Space Grotesk (bold, geometric — modern tech energy)
- **Body:** Inter (clean, readable)
- **Accent/mono:** JetBrains Mono (for numbers, dollar amounts, code-like elements)
- Scale: 96px hero → 64px section → 40px subsection → 24px card → 16px body

### Brand Essence
*The network that turns conversations into commissions — for ambitious connectors who want premium results without the grind.*
Personality: **Confident. Kinetic. Exclusive.**

### Brand Voice
Headlines sound like a movement, not a pitch. CTAs are invitations, not commands.
- "Build Connections. Earn Commissions. Change Businesses."
- "Your network has no limits. Neither do your earnings."
- Ban: "Welcome to our website", "Get started today", "Sign up now"

### Wordmark & Logo
Octagon shape with "OR" monogram inside. The octagon clips the content — the shape IS the brand.

### Signature Brand Color
Electric Cyan `#00d4ff` — unmistakably OctagonRon.

---

## Style Decisions
- Frosted glass: `backdrop-blur-xl bg-white/[0.04] border border-white/10`
- Glow effect: `box-shadow: 0 0 20px rgba(0,212,255,0.3)`
- Octagon clip: `clip-path: polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)`
- Section spacing: `py-32` minimum
- Card hover: `transform: translateY(-8px) rotateX(2deg) rotateY(2deg)`

## Style Decisions (Reviewer Amendments)
- **OctagonRon geometry rule:** all primary CTAs, major proof/data panels, timeline nodes, and network markers should use octagonal clipping, borders, or corner cuts so the octagon becomes the dominant brand shape rather than an occasional icon.
- **Composition rule:** avoid repeating centered headline-plus-card-grid sections; each major section must alternate asymmetric editorial/product weight and include one large environmental visual anchor tied to the particle network or octagon system.
- **Color rule:** electric cyan `#00d4ff` is the sole primary action/network-energy color, violet is used for premium depth, and gold appears only for earnings, rewards, leaderboard, and commission moments. Remove assorted colors from business/service cards.
