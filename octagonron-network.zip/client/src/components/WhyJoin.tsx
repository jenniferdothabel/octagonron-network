// OctagonRon Network — Why Join: orbiting glass icons + cinematic scenes
import { useEffect, useRef, useState } from "react";
import { GlassIcon, SvgIcon } from "./Icons";
import type { IconName } from "./Icons";

const BENEFITS: { icon: IconName; label: string }[] = [
  { icon: "package",      label: "No Inventory"         },
  { icon: "users",        label: "No Employees"         },
  { icon: "phone",        label: "No Cold Selling"      },
  { icon: "award",        label: "No Experience Needed" },
  { icon: "globe",        label: "Remote"               },
  { icon: "clock",        label: "Flexible"             },
  { icon: "refresh",      label: "Recurring"            },
  { icon: "headphones",   label: "Pro Support"          },
];

const SCENES: { title: string; subtitle: string; desc: string; icon: IconName; accent: "cyan" | "violet" | "gold" }[] = [
  {
    title: "Freedom",
    subtitle: "Earn from anywhere.",
    desc: "Check your commissions from a coffee shop, a beach, or your couch. The network works while you live.",
    icon: "coffee",
    accent: "cyan",
  },
  {
    title: "Flexibility",
    subtitle: "Refer on your schedule.",
    desc: "Waiting in line? That's a referral opportunity. No quotas. No pressure. Just conversations.",
    icon: "smartphone",
    accent: "violet",
  },
  {
    title: "Growth",
    subtitle: "Watch income compound.",
    desc: "Every introduction builds momentum. Watch your monthly commissions grow as your network expands.",
    icon: "trending-up",
    accent: "gold",
  },
];

export default function WhyJoin() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [time, setTime] = useState(0);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!visible) return;
    const interval = setInterval(() => setTime(t => t + 1), 50);
    return () => clearInterval(interval);
  }, [visible]);

  const getColor = (accent: string) =>
    accent === "cyan" ? "#00d4ff" : accent === "violet" ? "#8b5cf6" : "#fbbf24";

  return (
    <section
      style={{
        padding: "8rem 0",
        background: "linear-gradient(180deg, #080a0f 0%, #0a0d16 50%, #080a0f 100%)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        {/* Asymmetric: left editorial + right orbit */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "center", marginBottom: "6rem" }}>
          <div>
            <p style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "1rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
              WHY PARTNERS CHOOSE US
            </p>
            <h2 style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2.5rem, 5vw, 4rem)",
              fontWeight: 700, color: "#fff", lineHeight: 1.05, letterSpacing: "-0.02em",
              marginBottom: "1.5rem",
              opacity: visible ? 1 : 0,
              transform: visible ? "none" : "translateY(30px)",
              transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
            }}>
              Built for the<br />
              <span style={{ color: "#00d4ff" }}>Modern Connector.</span>
            </h2>
            <p style={{
              color: "rgba(255,255,255,0.5)", fontSize: "1rem", lineHeight: 1.7,
              opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.2s",
            }}>
              No inventory. No employees. No cold selling. Just conversations that turn into commissions.
            </p>
          </div>

          {/* Orbit */}
          <div style={{
            position: "relative", height: "360px",
            display: "flex", alignItems: "center", justifyContent: "center",
            opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.3s",
          }}>
            {/* Center octagon */}
            <div style={{ position: "absolute", zIndex: 2 }}>
              <div className="octagon" style={{
                width: "90px", height: "90px",
                background: "linear-gradient(135deg, rgba(0,212,255,0.15), rgba(139,92,246,0.15))",
                backdropFilter: "blur(20px)",
                border: "1.5px solid rgba(0,212,255,0.4)",
                display: "flex", alignItems: "center", justifyContent: "center",
                boxShadow: "0 0 40px rgba(0,212,255,0.2), inset 0 1px 0 rgba(255,255,255,0.1)",
              }}>
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "0.65rem", color: "#00d4ff" }}>OCTAGON</div>
                  <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "0.65rem", color: "#8b5cf6" }}>RON</div>
                </div>
              </div>
            </div>

            {/* Orbit ring */}
            <div style={{
              position: "absolute", width: "280px", height: "280px",
              borderRadius: "50%", border: "1px solid rgba(0,212,255,0.1)",
            }} />

            {/* Orbiting glass icons */}
            {BENEFITS.map((benefit, i) => {
              const angle = (i / BENEFITS.length) * Math.PI * 2 + (time * 0.008);
              const radius = 140;
              const x = Math.cos(angle) * radius;
              const y = Math.sin(angle) * radius;
              return (
                <div
                  key={benefit.label}
                  style={{
                    position: "absolute",
                    left: "50%", top: "50%",
                    transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
                    display: "flex", flexDirection: "column", alignItems: "center", gap: "0.2rem",
                    pointerEvents: "none",
                  }}
                >
                  <GlassIcon
                    name={benefit.icon}
                    size={38}
                    accent={i % 2 === 0 ? "cyan" : "violet"}
                    shape="octagon"
                    glow={false}
                  />
                  <span style={{
                    fontFamily: "'Inter', sans-serif", fontSize: "0.58rem",
                    color: "rgba(255,255,255,0.4)", textAlign: "center", whiteSpace: "nowrap",
                  }}>
                    {benefit.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Cinematic scenes */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1.25rem" }}>
          {SCENES.map((scene, i) => {
            const color = getColor(scene.accent);
            return (
              <div
                key={scene.title}
                style={{
                  background: `${color}08`,
                  backdropFilter: "blur(16px)",
                  WebkitBackdropFilter: "blur(16px)",
                  border: `1px solid ${color}20`,
                  clipPath: "polygon(16px 0%, calc(100% - 16px) 0%, 100% 16px, 100% calc(100% - 16px), calc(100% - 16px) 100%, 16px 100%, 0% calc(100% - 16px), 0% 16px)",
                  padding: "2.5rem 2rem",
                  opacity: visible ? 1 : 0,
                  transform: visible ? "none" : "translateY(40px)",
                  transition: `all 0.8s cubic-bezier(0.23,1,0.32,1) ${0.4 + i * 0.15}s`,
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                {/* Inner highlight */}
                <div style={{
                  position: "absolute", top: 0, left: 0, right: 0, height: "1px",
                  background: `linear-gradient(90deg, transparent, ${color}40, transparent)`,
                }} />

                <div style={{ marginBottom: "1.5rem", animation: `float 4s ease-in-out infinite`, animationDelay: `${i * 0.5}s` }}>
                  <GlassIcon name={scene.icon} size={56} accent={scene.accent} shape="octagon" glow />
                </div>
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem", color, letterSpacing: "0.2em", marginBottom: "0.5rem", opacity: 0.7 }}>
                  {scene.title.toUpperCase()}
                </div>
                <h3 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "1.35rem", color: "#fff", marginBottom: "0.75rem", lineHeight: 1.2 }}>
                  {scene.subtitle}
                </h3>
                <p style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.875rem", lineHeight: 1.7 }}>
                  {scene.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

