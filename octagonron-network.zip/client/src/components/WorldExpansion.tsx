// OctagonRon Network — World Expansion section with animated US map pins
import { useEffect, useRef, useState } from "react";

const LOCATIONS = [
  { name: "Louisville, KY", x: 52, y: 42, delay: 0 },
  { name: "Nashville, TN", x: 53, y: 48, delay: 0.3 },
  { name: "Indianapolis, IN", x: 52, y: 36, delay: 0.6 },
  { name: "Columbus, OH", x: 57, y: 33, delay: 0.9 },
  { name: "Cincinnati, OH", x: 55, y: 37, delay: 1.2 },
  { name: "Chicago, IL", x: 50, y: 29, delay: 1.5 },
  { name: "Atlanta, GA", x: 56, y: 55, delay: 1.8 },
  { name: "Charlotte, NC", x: 62, y: 48, delay: 2.1 },
  { name: "Detroit, MI", x: 55, y: 27, delay: 2.4 },
  { name: "St. Louis, MO", x: 48, y: 40, delay: 2.7 },
  { name: "Memphis, TN", x: 50, y: 50, delay: 3.0 },
  { name: "Pittsburgh, PA", x: 61, y: 32, delay: 3.3 },
  { name: "Cleveland, OH", x: 58, y: 30, delay: 3.6 },
  { name: "Kansas City, MO", x: 44, y: 38, delay: 3.9 },
  { name: "Minneapolis, MN", x: 46, y: 22, delay: 4.2 },
  { name: "Dallas, TX", x: 43, y: 57, delay: 4.5 },
  { name: "Houston, TX", x: 43, y: 63, delay: 4.8 },
  { name: "Phoenix, AZ", x: 22, y: 56, delay: 5.1 },
  { name: "Los Angeles, CA", x: 12, y: 52, delay: 5.4 },
  { name: "New York, NY", x: 68, y: 30, delay: 5.7 },
  { name: "Miami, FL", x: 62, y: 70, delay: 6.0 },
  { name: "Seattle, WA", x: 10, y: 18, delay: 6.3 },
  { name: "Denver, CO", x: 32, y: 38, delay: 6.6 },
  { name: "Boston, MA", x: 71, y: 26, delay: 6.9 },
];

export default function WorldExpansion() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [activePins, setActivePins] = useState<number[]>([]);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          LOCATIONS.forEach((loc, i) => {
            setTimeout(() => {
              setActivePins(prev => [...prev, i]);
            }, loc.delay * 1000);
          });
        }
      },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      style={{
        padding: "8rem 0",
        background: "#080a0f",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse at center, rgba(0,212,255,0.04) 0%, transparent 60%)",
        pointerEvents: "none",
      }} />

      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: "3rem" }}>
          <p style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "1rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
            NETWORK EXPANSION
          </p>
          <h2 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: "clamp(2.5rem, 5vw, 4rem)",
            fontWeight: 700,
            color: "#fff",
            lineHeight: 1.1,
            opacity: visible ? 1 : 0,
            transform: visible ? "none" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
          }}>
            Your Network<br />
            <span className="gradient-text">Has No Limits.</span>
          </h2>
          <p style={{
            color: "rgba(255,255,255,0.45)",
            marginTop: "1rem",
            fontSize: "1rem",
            opacity: visible ? 1 : 0,
            transition: "opacity 0.8s 0.2s",
          }}>
            Starting in Kentucky. Expanding across the nation. Eventually — the world.
          </p>
        </div>

        {/* Map container */}
        <div style={{
          position: "relative",
          width: "100%",
          maxWidth: "900px",
          margin: "0 auto",
          aspectRatio: "16/9",
          background: "rgba(0,212,255,0.02)",
          border: "1px solid rgba(0,212,255,0.1)",
          borderRadius: "1rem",
          overflow: "hidden",
          opacity: visible ? 1 : 0,
          transition: "opacity 0.8s 0.3s",
        }}>
          {/* Grid overlay */}
          <div style={{
            position: "absolute", inset: 0,
            backgroundImage: "linear-gradient(rgba(0,212,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,0.04) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }} />

          {/* US outline (simplified SVG) */}
          <svg
            viewBox="0 0 900 506"
            style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.15 }}
            fill="none"
          >
            <path
              d="M80,120 L100,90 L140,80 L180,70 L220,65 L260,60 L300,58 L340,55 L380,52 L420,50 L460,48 L500,47 L540,46 L580,48 L620,50 L660,55 L700,58 L730,62 L750,70 L760,80 L755,100 L760,120 L770,140 L780,160 L790,180 L800,200 L810,220 L820,240 L825,260 L820,280 L810,300 L800,320 L790,340 L780,360 L770,380 L760,400 L750,420 L740,440 L720,450 L700,455 L680,458 L660,460 L640,462 L620,460 L600,455 L580,450 L560,445 L540,440 L520,438 L500,436 L480,438 L460,440 L440,442 L420,440 L400,435 L380,430 L360,425 L340,420 L320,415 L300,410 L280,405 L260,400 L240,395 L220,390 L200,380 L180,370 L160,355 L140,340 L120,320 L100,300 L85,280 L75,260 L70,240 L72,220 L75,200 L78,180 L80,160 L80,140 Z"
              stroke="#00d4ff"
              strokeWidth="1.5"
              fill="rgba(0,212,255,0.05)"
            />
          </svg>

          {/* Pins */}
          {LOCATIONS.map((loc, i) => (
            <div
              key={loc.name}
              style={{
                position: "absolute",
                left: `${loc.x}%`,
                top: `${loc.y}%`,
                transform: "translate(-50%, -50%)",
                opacity: activePins.includes(i) ? 1 : 0,
                transition: "opacity 0.4s",
              }}
            >
              {/* Pulse ring */}
              <div style={{
                position: "absolute",
                top: "50%", left: "50%",
                transform: "translate(-50%,-50%)",
                width: "20px", height: "20px",
                borderRadius: "50%",
                border: "1px solid rgba(0,212,255,0.5)",
                animation: activePins.includes(i) ? "pulse-glow 2s ease-in-out infinite" : "none",
                animationDelay: `${i * 0.1}s`,
              }} />
              {/* Dot */}
              <div style={{
                width: "6px", height: "6px",
                borderRadius: "50%",
                background: i < 5 ? "#00d4ff" : i < 12 ? "#8b5cf6" : "rgba(0,212,255,0.6)",
                boxShadow: `0 0 8px ${i < 5 ? "#00d4ff" : "#8b5cf6"}`,
              }} />
            </div>
          ))}

          {/* Connection lines between nearby pins */}
          <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}>
            {activePins.length > 3 && LOCATIONS.slice(0, Math.min(activePins.length, LOCATIONS.length)).map((loc, i) => {
              if (i === 0) return null;
              const prev = LOCATIONS[Math.max(0, i - 1)];
              const dx = loc.x - prev.x;
              const dy = loc.y - prev.y;
              const dist = Math.sqrt(dx*dx + dy*dy);
              if (dist > 15) return null;
              return (
                <line
                  key={i}
                  x1={`${prev.x}%`} y1={`${prev.y}%`}
                  x2={`${loc.x}%`} y2={`${loc.y}%`}
                  stroke="rgba(0,212,255,0.2)"
                  strokeWidth="1"
                />
              );
            })}
          </svg>

          {/* Label */}
          <div style={{
            position: "absolute",
            bottom: "1rem", left: "50%",
            transform: "translateX(-50%)",
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: "0.7rem",
            color: "rgba(0,212,255,0.5)",
            letterSpacing: "0.2em",
          }}>
            {activePins.length} CITIES CONNECTED
          </div>
        </div>

        <div style={{ textAlign: "center", marginTop: "3rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s 1s" }}>
          <p style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.8rem", letterSpacing: "0.15em" }}>
            EVERY CONNECTION EXPANDS THE NETWORK
          </p>
        </div>
      </div>
    </section>
  );
}

