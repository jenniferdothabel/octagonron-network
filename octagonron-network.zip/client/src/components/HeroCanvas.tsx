// OctagonRon Network — Animated particle network canvas
// Matte black background, glowing nodes connected by lines, converging on octagon center
// Money values briefly materialize as new nodes appear
import { useEffect, useRef, useCallback } from "react";

interface Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  opacity: number;
  pulsePhase: number;
  isCenter?: boolean;
  icon?: string;
}

interface Pulse {
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  progress: number;
  speed: number;
  color: string;
}

interface MoneyPop {
  x: number;
  y: number;
  value: string;
  life: number;
  maxLife: number;
}

const MONEY_VALUES = ["+$750", "+$1,200", "+$400", "+$2,800", "+$950", "+$3,400", "+$620"];
const COLORS = { cyan: "#00d4ff", violet: "#8b5cf6" };
const ICONS = ["🏠", "🔧", "⚖️", "🦷", "🚗", "🍕", "🏢", "🏥", "💼", "🏗️"];

export default function HeroCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nodesRef = useRef<Node[]>([]);
  const pulsesRef = useRef<Pulse[]>([]);
  const moneyPopsRef = useRef<MoneyPop[]>([]);
  const rafRef = useRef<number>(0);
  const timeRef = useRef(0);
  const lastMoneyRef = useRef(0);
  const lastNodeRef = useRef(0);

  const initNodes = useCallback((w: number, h: number) => {
    const nodes: Node[] = [];
    const count = Math.min(Math.floor((w * h) / 18000), 55);

    // Center octagon node
    nodes.push({
      x: w / 2, y: h / 2,
      vx: 0, vy: 0,
      radius: 14, opacity: 1,
      pulsePhase: 0,
      isCenter: true,
    });

    for (let i = 0; i < count; i++) {
      nodes.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        radius: Math.random() * 3 + 2,
        opacity: Math.random() * 0.5 + 0.4,
        pulsePhase: Math.random() * Math.PI * 2,
        icon: Math.random() > 0.6 ? ICONS[Math.floor(Math.random() * ICONS.length)] : undefined,
      });
    }
    nodesRef.current = nodes;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      initNodes(canvas.offsetWidth, canvas.offsetHeight);
    };

    resize();
    window.addEventListener("resize", resize);

    const drawOctagon = (ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) => {
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const angle = (i * Math.PI) / 4 - Math.PI / 8;
        const x = cx + r * Math.cos(angle);
        const y = cy + r * Math.sin(angle);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
    };

    const animate = (timestamp: number) => {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      timeRef.current = timestamp;

      ctx.clearRect(0, 0, w, h);

      const nodes = nodesRef.current;
      const pulses = pulsesRef.current;
      const moneyPops = moneyPopsRef.current;
      const MAX_DIST = 180;

      // Update nodes
      nodes.forEach((node, i) => {
        if (node.isCenter) return;
        node.x += node.vx;
        node.y += node.vy;
        if (node.x < 0 || node.x > w) node.vx *= -1;
        if (node.y < 0 || node.y > h) node.vy *= -1;
        node.pulsePhase += 0.02;

        // Gentle attraction toward center
        const dx = w / 2 - node.x;
        const dy = h / 2 - node.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 250) {
          node.vx += dx * 0.00003;
          node.vy += dy * 0.00003;
        }
      });

      // Draw connections
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < MAX_DIST) {
            const alpha = (1 - dist / MAX_DIST) * 0.25;
            const isCenterConn = nodes[i].isCenter || nodes[j].isCenter;
            const color = isCenterConn ? `rgba(0,212,255,${alpha * 2})` : `rgba(139,92,246,${alpha})`;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.strokeStyle = color;
            ctx.lineWidth = isCenterConn ? 1.5 : 0.8;
            ctx.stroke();
          }
        }
      }

      // Draw pulses (traveling dots along connections)
      pulses.forEach((pulse, pi) => {
        pulse.progress += pulse.speed;
        if (pulse.progress >= 1) {
          pulses.splice(pi, 1);
          return;
        }
        const px = pulse.fromX + (pulse.toX - pulse.fromX) * pulse.progress;
        const py = pulse.fromY + (pulse.toY - pulse.fromY) * pulse.progress;
        const alpha = Math.sin(pulse.progress * Math.PI);
        ctx.beginPath();
        ctx.arc(px, py, 3, 0, Math.PI * 2);
        ctx.fillStyle = pulse.color.replace(")", `,${alpha})`).replace("rgb", "rgba");
        ctx.shadowBlur = 12;
        ctx.shadowColor = pulse.color;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // Draw nodes
      nodes.forEach(node => {
        const pulse = Math.sin(node.pulsePhase) * 0.3 + 0.7;

        if (node.isCenter) {
          // Glowing octagon center
          const glowSize = 20 + Math.sin(timestamp * 0.002) * 5;
          const grad = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, glowSize * 3);
          grad.addColorStop(0, "rgba(0,212,255,0.3)");
          grad.addColorStop(0.5, "rgba(0,212,255,0.1)");
          grad.addColorStop(1, "rgba(0,212,255,0)");
          ctx.beginPath();
          ctx.arc(node.x, node.y, glowSize * 3, 0, Math.PI * 2);
          ctx.fillStyle = grad;
          ctx.fill();

          // Octagon shape
          ctx.save();
          ctx.shadowBlur = 30;
          ctx.shadowColor = "#00d4ff";
          drawOctagon(ctx, node.x, node.y, glowSize);
          ctx.fillStyle = "rgba(0,212,255,0.15)";
          ctx.fill();
          ctx.strokeStyle = "#00d4ff";
          ctx.lineWidth = 2;
          ctx.stroke();
          ctx.restore();

          // "OR" text
          ctx.font = "bold 11px 'Space Grotesk', sans-serif";
          ctx.fillStyle = "#00d4ff";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText("OR", node.x, node.y);
        } else {
          // Regular node
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.radius * pulse, 0, Math.PI * 2);
          const isViolet = (nodesRef.current.indexOf(node) % 3 === 0);
          ctx.fillStyle = isViolet
            ? `rgba(139,92,246,${node.opacity * pulse})`
            : `rgba(0,212,255,${node.opacity * pulse})`;
          ctx.shadowBlur = 8;
          ctx.shadowColor = isViolet ? "#8b5cf6" : "#00d4ff";
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      });

      // Spawn new pulses periodically
      if (timestamp - lastNodeRef.current > 800) {
        lastNodeRef.current = timestamp;
        const nonCenter = nodes.filter(n => !n.isCenter);
        if (nonCenter.length > 1) {
          const from = nonCenter[Math.floor(Math.random() * nonCenter.length)];
          const center = nodes[0];
          pulses.push({
            fromX: from.x, fromY: from.y,
            toX: center.x, toY: center.y,
            progress: 0,
            speed: 0.008 + Math.random() * 0.006,
            color: Math.random() > 0.5 ? "rgb(0,212,255)" : "rgb(139,92,246)",
          });
        }
      }

      // Money pops
      if (timestamp - lastMoneyRef.current > 2200) {
        lastMoneyRef.current = timestamp;
        const nonCenter = nodes.filter(n => !n.isCenter);
        if (nonCenter.length > 0) {
          const node = nonCenter[Math.floor(Math.random() * nonCenter.length)];
          moneyPops.push({
            x: node.x,
            y: node.y,
            value: MONEY_VALUES[Math.floor(Math.random() * MONEY_VALUES.length)],
            life: 0,
            maxLife: 120,
          });
        }
      }

      // Draw money pops
      moneyPops.forEach((pop, pi) => {
        pop.life++;
        if (pop.life >= pop.maxLife) {
          moneyPops.splice(pi, 1);
          return;
        }
        const t = pop.life / pop.maxLife;
        const alpha = t < 0.2 ? t / 0.2 : t > 0.7 ? 1 - (t - 0.7) / 0.3 : 1;
        const yOffset = -pop.life * 0.5;
        ctx.font = "bold 13px 'JetBrains Mono', monospace";
        ctx.fillStyle = `rgba(0,212,255,${alpha})`;
        ctx.textAlign = "center";
        ctx.shadowBlur = 10;
        ctx.shadowColor = "#00d4ff";
        ctx.fillText(pop.value, pop.x, pop.y + yOffset);
        ctx.shadowBlur = 0;
      });

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(rafRef.current);
    };
  }, [initNodes]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        display: "block",
      }}
    />
  );
}

