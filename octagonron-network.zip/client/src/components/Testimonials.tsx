// OctagonRon Network — Floating conversation bubble testimonials
import { useEffect, useRef, useState } from "react";

const TESTIMONIALS = [
  { quote: "I introduced one client. Made $400.", name: "Sarah M.", role: "Partner since 2023", color: "#00d4ff", side: "left" },
  { quote: "I never had to sell anything. Just made the introduction.", name: "James R.", role: "Partner since 2024", color: "#8b5cf6", side: "right" },
  { quote: "They handled every question. I just collected the check.", name: "Priya K.", role: "Partner since 2023", color: "#10b981", side: "left" },
  { quote: "My first referral closed in 3 days. Commission hit my account the same week.", name: "Marcus T.", role: "Partner since 2024", color: "#fbbf24", side: "right" },
  { quote: "I referred my dentist. Now I earn every time they renew.", name: "Lisa W.", role: "Partner since 2022", color: "#f472b6", side: "left" },
  { quote: "This isn't a side hustle. It's a system.", name: "Derek N.", role: "Partner since 2023", color: "#00d4ff", side: "right" },
];

export default function Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      style={{
        padding: "8rem 0",
        background: "linear-gradient(180deg, #080a0f 0%, #0a0d16 100%)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "radial-gradient(circle at 30% 70%, rgba(139,92,246,0.05) 0%, transparent 50%), radial-gradient(circle at 70% 30%, rgba(0,212,255,0.05) 0%, transparent 50%)",
        pointerEvents: "none",
      }} />

      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <p style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "1rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
            PARTNER VOICES
          </p>
          <h2 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: "clamp(2.5rem, 5vw, 3.75rem)",
            fontWeight: 700,
            color: "#fff",
            opacity: visible ? 1 : 0,
            transform: visible ? "none" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
          }}>
            Real Partners.<br />
            <span className="gradient-text">Real Income.</span>
          </h2>
        </div>

        <div style={{ maxWidth: "700px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
          {TESTIMONIALS.map((t, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                justifyContent: t.side === "right" ? "flex-end" : "flex-start",
                opacity: visible ? 1 : 0,
                transform: visible ? "none" : `translateX(${t.side === "right" ? "30px" : "-30px"})`,
                transition: `all 0.7s cubic-bezier(0.23,1,0.32,1) ${i * 0.12}s`,
              }}
            >
              <div style={{
                maxWidth: "80%",
                background: `linear-gradient(135deg, ${t.color}10 0%, rgba(255,255,255,0.03) 100%)`,
                border: `1px solid ${t.color}30`,
                borderRadius: t.side === "right" ? "1.25rem 0.25rem 1.25rem 1.25rem" : "0.25rem 1.25rem 1.25rem 1.25rem",
                padding: "1.5rem 1.75rem",
                position: "relative",
                boxShadow: `0 4px 30px ${t.color}10`,
              }}>
                {/* Quote mark */}
                <div style={{
                  position: "absolute",
                  top: "-0.5rem",
                  left: t.side === "right" ? "auto" : "1.25rem",
                  right: t.side === "right" ? "1.25rem" : "auto",
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: "3rem",
                  color: t.color,
                  opacity: 0.3,
                  lineHeight: 1,
                }}>
                  "
                </div>
                <p style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: "1.05rem",
                  fontWeight: 500,
                  color: "#fff",
                  lineHeight: 1.6,
                  marginBottom: "0.875rem",
                }}>
                  "{t.quote}"
                </p>
                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                  <div style={{
                    width: "28px", height: "28px",
                    borderRadius: "50%",
                    background: `linear-gradient(135deg, ${t.color}, ${t.color}80)`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "0.7rem",
                    fontWeight: 700,
                    color: "#080a0f",
                    fontFamily: "'Space Grotesk', sans-serif",
                  }}>
                    {t.name[0]}
                  </div>
                  <div>
                    <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 600, fontSize: "0.8rem", color: t.color }}>{t.name}</div>
                    <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.7rem", color: "rgba(255,255,255,0.35)" }}>{t.role}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

