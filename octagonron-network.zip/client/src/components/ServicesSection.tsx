// OctagonRon Network — Services with professional glass SVG icons
// Color discipline: cyan + violet only
import { useState, useEffect, useRef } from "react";
import { GlassIcon } from "./Icons";
import type { IconName } from "./Icons";

const SERVICES: { icon: IconName; name: string; desc: string; accent: "cyan" | "violet" }[] = [
  { icon: "globe",     name: "Website Design",      desc: "Stunning, conversion-focused websites",    accent: "cyan"   },
  { icon: "bot",       name: "AI Receptionist",      desc: "24/7 automated phone answering",           accent: "violet" },
  { icon: "zap",       name: "Automation",           desc: "Streamline any business workflow",         accent: "cyan"   },
  { icon: "database",  name: "CRM Systems",          desc: "Track every lead and customer",            accent: "violet" },
  { icon: "phone",     name: "Phone Systems",        desc: "Professional VoIP & call routing",         accent: "cyan"   },
  { icon: "target",    name: "Lead Generation",      desc: "Fill the pipeline with qualified leads",   accent: "violet" },
  { icon: "briefcase", name: "Business Consulting",  desc: "Strategic growth advisory",                accent: "cyan"   },
];

export default function ServicesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [hovered, setHovered] = useState<number | null>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const getColor = (accent: "cyan" | "violet") => accent === "cyan" ? "#00d4ff" : "#8b5cf6";

  return (
    <section
      id="services"
      style={{
        padding: "8rem 0",
        background: "linear-gradient(180deg, #060810 0%, #080a0f 100%)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "radial-gradient(circle at 80% 50%, rgba(139,92,246,0.06) 0%, transparent 50%), radial-gradient(circle at 20% 20%, rgba(0,212,255,0.06) 0%, transparent 50%)",
        pointerEvents: "none",
      }} />

      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        {/* Asymmetric header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "4rem", flexWrap: "wrap", gap: "2rem" }}>
          <div>
            <p style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "1rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
              WHAT WE BUILD
            </p>
            <h2 style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2.5rem, 5vw, 3.75rem)",
              fontWeight: 700, color: "#fff", lineHeight: 1.05, letterSpacing: "-0.02em",
              opacity: visible ? 1 : 0,
              transform: visible ? "none" : "translateY(30px)",
              transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
            }}>
              Every Tool a Business<br />
              <span style={{ color: "#00d4ff" }}>Could Ever Need.</span>
            </h2>
          </div>
          <div style={{ opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.3s", maxWidth: "280px" }}>
            <p style={{ color: "rgba(255,255,255,0.4)", fontSize: "0.9rem", lineHeight: 1.6, fontFamily: "'Inter', sans-serif" }}>
              Seven services. One introduction. You never need to know how any of it works.
            </p>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "1rem" }}>
          {SERVICES.map((svc, i) => {
            const color = getColor(svc.accent);
            const isHov = hovered === i;
            return (
              <div
                key={svc.name}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                style={{
                  background: isHov
                    ? `linear-gradient(135deg, ${color}0d 0%, rgba(255,255,255,0.03) 100%)`
                    : "rgba(255,255,255,0.03)",
                  backdropFilter: "blur(16px)",
                  WebkitBackdropFilter: "blur(16px)",
                  border: `1px solid ${isHov ? color + "45" : "rgba(255,255,255,0.07)"}`,
                  clipPath: "polygon(12px 0%, calc(100% - 12px) 0%, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0% calc(100% - 12px), 0% 12px)",
                  padding: "2rem",
                  cursor: "default",
                  opacity: visible ? 1 : 0,
                  transform: visible ? (isHov ? "translateY(-8px)" : "translateY(0)") : "translateY(30px)",
                  transition: `all 0.5s cubic-bezier(0.23,1,0.32,1) ${i * 0.07}s`,
                  boxShadow: isHov ? `0 20px 60px rgba(0,0,0,0.4), 0 0 30px ${color}15` : "none",
                  position: "relative",
                }}
              >
                {/* Glass icon */}
                <div style={{ marginBottom: "1.25rem" }}>
                  <GlassIcon
                    name={svc.icon}
                    size={52}
                    accent={svc.accent}
                    shape="octagon"
                    glow={isHov}
                  />
                </div>

                <h3 style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontWeight: 700, fontSize: "1rem",
                  color: isHov ? color : "#fff",
                  marginBottom: "0.5rem",
                  transition: "color 0.3s",
                }}>
                  {svc.name}
                </h3>
                <p style={{ color: "rgba(255,255,255,0.4)", fontSize: "0.85rem", lineHeight: 1.6 }}>
                  {svc.desc}
                </p>

                {/* Corner octagon accent */}
                <div style={{
                  position: "absolute", bottom: "1rem", right: "1rem",
                  width: "18px", height: "18px",
                  clipPath: "polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)",
                  background: isHov ? color : "rgba(255,255,255,0.07)",
                  transition: "background 0.3s",
                }} />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
