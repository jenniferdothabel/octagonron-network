// OctagonRon Network — Final CTA: explosive octagon, heartbeat, neuron burst on click
import { useEffect, useRef, useState } from "react";

export default function FinalCTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [visible, setVisible] = useState(false);
  const [exploded, setExploded] = useState(false);
  const [showText, setShowText] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [octSize, setOctSize] = useState(120);
  const rafRef = useRef<number>(0);
  const particlesRef = useRef<Array<{ x: number; y: number; vx: number; vy: number; life: number; color: string }>>([]);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Canvas explosion animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !exploded) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;

    // Spawn burst particles
    for (let i = 0; i < 120; i++) {
      const angle = (i / 120) * Math.PI * 2;
      const speed = 2 + Math.random() * 8;
      particlesRef.current.push({
        x: cx, y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1,
        color: Math.random() > 0.5 ? "#00d4ff" : "#8b5cf6",
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particlesRef.current = particlesRef.current.filter(p => p.life > 0);
      particlesRef.current.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.97;
        p.vy *= 0.97;
        p.life -= 0.015;

        ctx.beginPath();
        ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(")", `,${p.life})`).replace("rgb", "rgba").replace("#00d4ff", "rgba(0,212,255,").replace("#8b5cf6", "rgba(139,92,246,");
        ctx.shadowBlur = 8;
        ctx.shadowColor = p.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Draw connection lines to nearby particles
        particlesRef.current.forEach(p2 => {
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx*dx + dy*dy);
          if (dist < 60) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(0,212,255,${(1 - dist/60) * p.life * 0.3})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        });
      });

      if (particlesRef.current.length > 0) {
        rafRef.current = requestAnimationFrame(animate);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [exploded]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = e.clientX - cx;
    const dy = e.clientY - cy;
    const dist = Math.sqrt(dx*dx + dy*dy);
    const maxDist = 300;
    const scale = Math.max(0, 1 - dist / maxDist);
    setOctSize(120 + scale * 60);
    setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  const handleClick = () => {
    setExploded(true);
    setTimeout(() => setShowText(true), 600);
  };

  return (
    <section
      id="final-cta"
      ref={sectionRef}
      onMouseMove={handleMouseMove}
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: "#040508",
        position: "relative",
        overflow: "hidden",
        cursor: "none",
      }}
    >
      {/* Explosion canvas */}
      <canvas
        ref={canvasRef}
        style={{
          position: "absolute", inset: 0,
          width: "100%", height: "100%",
          pointerEvents: "none",
          zIndex: 2,
        }}
      />

      {/* Background network dots */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "radial-gradient(circle, rgba(0,212,255,0.15) 1px, transparent 1px)",
        backgroundSize: "40px 40px",
        opacity: exploded ? 0.5 : 0.15,
        transition: "opacity 1s",
        pointerEvents: "none",
      }} />

      {/* Ambient glow */}
      <div style={{
        position: "absolute", inset: 0,
        background: `radial-gradient(circle at ${mousePos.x}px ${mousePos.y}px, rgba(0,212,255,0.08) 0%, transparent 40%)`,
        pointerEvents: "none",
        transition: "background 0.1s",
      }} />

      <div style={{ position: "relative", zIndex: 3, textAlign: "center", padding: "2rem" }}>
        {!showText ? (
          <>
            <p style={{
              color: "rgba(255,255,255,0.3)",
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: "0.75rem",
              letterSpacing: "0.25em",
              marginBottom: "3rem",
              opacity: visible ? 1 : 0,
              transition: "opacity 0.8s 0.3s",
            }}>
              CLICK THE OCTAGON
            </p>

            {/* The Octagon */}
            <div
              onClick={handleClick}
              style={{
                width: `${octSize}px`,
                height: `${octSize}px`,
                clipPath: "polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)",
                background: "linear-gradient(135deg, rgba(0,212,255,0.2), rgba(139,92,246,0.2))",
                border: "none",
                cursor: "none",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto",
                transition: "width 0.3s cubic-bezier(0.23,1,0.32,1), height 0.3s cubic-bezier(0.23,1,0.32,1)",
                boxShadow: `0 0 ${octSize * 0.4}px rgba(0,212,255,0.3), 0 0 ${octSize * 0.8}px rgba(0,212,255,0.1)`,
                animation: "heartbeat 2s ease-in-out infinite",
                position: "relative",
                opacity: visible ? 1 : 0,
                transform: visible ? "none" : "scale(0.8)",
              }}
            >
              {/* Inner ring */}
              <div style={{
                width: "70%", height: "70%",
                clipPath: "polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)",
                background: "linear-gradient(135deg, rgba(0,212,255,0.4), rgba(139,92,246,0.4))",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <span style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontWeight: 700,
                  fontSize: "1.1rem",
                  color: "#fff",
                  letterSpacing: "0.05em",
                }}>
                  OR
                </span>
              </div>
            </div>

            <p style={{
              marginTop: "2.5rem",
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(1.5rem, 3vw, 2.25rem)",
              fontWeight: 700,
              color: "rgba(255,255,255,0.8)",
              lineHeight: 1.3,
              opacity: visible ? 1 : 0,
              transition: "opacity 0.8s 0.5s",
            }}>
              Ready to Turn Conversations<br />
              <span className="gradient-text">Into Income?</span>
            </p>
          </>
        ) : (
          <div style={{
            animation: "count-up 0.8s cubic-bezier(0.23,1,0.32,1) forwards",
          }}>
            <div style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: "0.75rem",
              color: "#00d4ff",
              letterSpacing: "0.3em",
              marginBottom: "1.5rem",
              opacity: 0.7,
            }}>
              WELCOME TO THE NETWORK
            </div>
            <h2 style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2.5rem, 6vw, 5rem)",
              fontWeight: 700,
              color: "#fff",
              lineHeight: 1.1,
              marginBottom: "2.5rem",
            }}>
              Build Relationships.<br />
              <span className="gradient-text">Build Income.</span><br />
              Build the Network.
            </h2>
            <a
              href="#"
              className="btn-primary"
              style={{ fontSize: "1.1rem", padding: "1.125rem 3rem", display: "inline-block", textDecoration: "none" }}
              onClick={e => e.preventDefault()}
            >
              Apply to Become a Partner
            </a>
            <p style={{ marginTop: "1.5rem", color: "rgba(255,255,255,0.3)", fontSize: "0.85rem", fontFamily: "'Inter', sans-serif" }}>
              No experience required. No inventory. No cold calling.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

