// OctagonRon Network — Octagon-shaped scroll progress indicator
import { useEffect, useState } from "react";

export default function ScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(docHeight > 0 ? scrollTop / docHeight : 0);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Octagon SVG path for progress ring
  const size = 52;
  const cx = size / 2;
  const cy = size / 2;
  const r = 20;
  // Approximate octagon perimeter
  const perimeter = 8 * r * Math.tan(Math.PI / 8) * 2;
  const dashOffset = perimeter * (1 - progress);

  // Octagon points
  const pts = Array.from({ length: 8 }, (_, i) => {
    const angle = (i * Math.PI) / 4 - Math.PI / 8;
    return `${cx + r * Math.cos(angle)},${cy + r * Math.sin(angle)}`;
  }).join(" ");

  if (progress < 0.01) return null;

  return (
    <div
      style={{
        position: "fixed",
        bottom: "2rem",
        right: "2rem",
        zIndex: 1000,
        pointerEvents: "none",
      }}
    >
      <svg width={size} height={size} style={{ overflow: "visible" }}>
        {/* Track */}
        <polygon
          points={pts}
          fill="none"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="2"
        />
        {/* Progress */}
        <polygon
          points={pts}
          fill="none"
          stroke="url(#octProgress)"
          strokeWidth="2.5"
          strokeDasharray={perimeter}
          strokeDashoffset={dashOffset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 0.1s linear" }}
        />
        <defs>
          <linearGradient id="octProgress" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" />
            <stop offset="100%" stopColor="#8b5cf6" />
          </linearGradient>
        </defs>
        {/* Center dot */}
        <circle cx={cx} cy={cy} r="3" fill="#00d4ff" opacity="0.8" />
      </svg>
    </div>
  );
}

