// OctagonRon Network — Custom electric cursor with trail effect
import { useEffect, useRef } from "react";

export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const trailsRef = useRef<HTMLDivElement[]>([]);
  const posRef = useRef({ x: -100, y: -100 });
  const ringPosRef = useRef({ x: -100, y: -100 });
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const TRAIL_COUNT = 8;
    const container = document.getElementById("cursor-container");
    if (!container) return;

    // Create trail elements
    for (let i = 0; i < TRAIL_COUNT; i++) {
      const trail = document.createElement("div");
      trail.style.cssText = `
        position: fixed; pointer-events: none; z-index: 99998;
        width: ${6 - i * 0.5}px; height: ${6 - i * 0.5}px;
        border-radius: 50%;
        background: rgba(0,212,255,${0.6 - i * 0.07});
        transform: translate(-50%,-50%);
        transition: opacity 0.1s;
        left: -100px; top: -100px;
      `;
      container.appendChild(trail);
      trailsRef.current.push(trail);
    }

    const trailPositions = Array(TRAIL_COUNT).fill({ x: -100, y: -100 });

    const onMove = (e: MouseEvent) => {
      posRef.current = { x: e.clientX, y: e.clientY };
    };

    const onEnter = () => {
      if (dotRef.current) dotRef.current.style.opacity = "1";
      if (ringRef.current) ringRef.current.style.opacity = "1";
    };

    const onLeave = () => {
      if (dotRef.current) dotRef.current.style.opacity = "0";
      if (ringRef.current) ringRef.current.style.opacity = "0";
    };

    const onDown = () => {
      if (ringRef.current) {
        ringRef.current.style.transform = "translate(-50%,-50%) scale(0.8)";
        ringRef.current.style.borderColor = "#8b5cf6";
      }
    };

    const onUp = () => {
      if (ringRef.current) {
        ringRef.current.style.transform = "translate(-50%,-50%) scale(1)";
        ringRef.current.style.borderColor = "rgba(0,212,255,0.6)";
      }
    };

    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseenter", onEnter);
    document.addEventListener("mouseleave", onLeave);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("mouseup", onUp);

    let trailIndex = 0;

    const animate = () => {
      const { x, y } = posRef.current;

      if (dotRef.current) {
        dotRef.current.style.left = x + "px";
        dotRef.current.style.top = y + "px";
      }

      // Smooth ring follow
      ringPosRef.current.x += (x - ringPosRef.current.x) * 0.12;
      ringPosRef.current.y += (y - ringPosRef.current.y) * 0.12;
      if (ringRef.current) {
        ringRef.current.style.left = ringPosRef.current.x + "px";
        ringRef.current.style.top = ringPosRef.current.y + "px";
      }

      // Trail
      trailPositions[trailIndex] = { x, y };
      trailIndex = (trailIndex + 1) % TRAIL_COUNT;
      for (let i = 0; i < TRAIL_COUNT; i++) {
        const idx = (trailIndex - i - 1 + TRAIL_COUNT) % TRAIL_COUNT;
        const el = trailsRef.current[i];
        if (el && trailPositions[idx]) {
          el.style.left = trailPositions[idx].x + "px";
          el.style.top = trailPositions[idx].y + "px";
        }
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseenter", onEnter);
      document.removeEventListener("mouseleave", onLeave);
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("mouseup", onUp);
      cancelAnimationFrame(rafRef.current);
      trailsRef.current.forEach(t => t.remove());
      trailsRef.current = [];
    };
  }, []);

  return (
    <>
      {/* Dot */}
      <div
        ref={dotRef}
        style={{
          position: "fixed",
          pointerEvents: "none",
          zIndex: 99999,
          width: "8px",
          height: "8px",
          borderRadius: "50%",
          background: "#00d4ff",
          transform: "translate(-50%,-50%)",
          left: "-100px",
          top: "-100px",
          boxShadow: "0 0 10px rgba(0,212,255,0.8)",
          transition: "opacity 0.2s",
        }}
      />
      {/* Ring */}
      <div
        ref={ringRef}
        style={{
          position: "fixed",
          pointerEvents: "none",
          zIndex: 99998,
          width: "36px",
          height: "36px",
          borderRadius: "50%",
          border: "1.5px solid rgba(0,212,255,0.6)",
          transform: "translate(-50%,-50%)",
          left: "-100px",
          top: "-100px",
          transition: "transform 0.15s cubic-bezier(0.23,1,0.32,1), border-color 0.15s, opacity 0.2s",
        }}
      />
      <div id="cursor-container" />
    </>
  );
}

