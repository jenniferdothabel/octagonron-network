// OctagonRon Network — Animated process timeline with octagon SVG nodes
import { useEffect, useRef, useState } from "react";
import { GlassIcon } from "./Icons";
import type { IconName } from "./Icons";

const STEPS: { label: string; desc: string; icon: IconName; accent: "cyan" | "violet" | "gold" }[] = [
  { label: "Lead",       desc: "A business owner enters your network",       icon: "user",        accent: "cyan"   },
  { label: "Discovery",  desc: "We learn about their needs and goals",        icon: "search",      accent: "cyan"   },
  { label: "Proposal",   desc: "Custom solution crafted and presented",       icon: "file-text",   accent: "violet" },
  { label: "Deposit",    desc: "Client commits and project is funded",        icon: "credit-card", accent: "violet" },
  { label: "Build",      desc: "Our team executes with precision",            icon: "cpu",         accent: "cyan"   },
  { label: "Delivery",   desc: "Solution delivered and client thrilled",      icon: "rocket",      accent: "cyan"   },
  { label: "Commission", desc: "Your payment hits. Automatically.",           icon: "dollar",      accent: "gold"   },
];

export default function ProcessTimeline() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeStep, setActiveStep] = useState(-1);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          STEPS.forEach((_, i) => {
            setTimeout(() => setActiveStep(i), i * 380);
          });
        }
      },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      style={{
        padding: "8rem 0",
        background: "#080a0f",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{
        position: "absolute", right: "-5%", top: "20%",
        width: "400px", height: "400px",
        background: "radial-gradient(circle, rgba(139,92,246,0.07) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        <div style={{ maxWidth: "500px", marginBottom: "5rem" }}>
          <p style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "1rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
            THE PROCESS
          </p>
          <h2 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: "clamp(2.5rem, 5vw, 3.75rem)",
            fontWeight: 700, color: "#fff", lineHeight: 1.05, letterSpacing: "-0.02em",
            opacity: visible ? 1 : 0,
            transform: visible ? "none" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
          }}>
            From Introduction<br />
            <span style={{ color: "#00d4ff" }}>to Commission.</span>
          </h2>
        </div>

        {/* Horizontal timeline */}
        <div style={{ position: "relative" }}>
          {/* Track */}
          <div style={{
            position: "absolute", top: "28px", left: "0", right: "0",
            height: "2px", background: "rgba(255,255,255,0.06)",
          }} />
          {/* Progress */}
          <div style={{
            position: "absolute", top: "28px", left: "0",
            height: "2px",
            width: `${((activeStep + 1) / STEPS.length) * 100}%`,
            background: "linear-gradient(90deg, #00d4ff, #8b5cf6, #fbbf24)",
            transition: "width 0.4s cubic-bezier(0.23,1,0.32,1)",
            boxShadow: "0 0 10px rgba(0,212,255,0.5)",
          }} />

          <div style={{ display: "grid", gridTemplateColumns: `repeat(${STEPS.length}, 1fr)`, gap: "0.5rem" }}>
            {STEPS.map((step, i) => {
              const isActive = activeStep >= i;
              return (
                <div key={step.label} style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                  {/* Glass octagon node */}
                  <div style={{
                    marginBottom: "1.25rem",
                    opacity: isActive ? 1 : 0.3,
                    transform: isActive ? "scale(1)" : "scale(0.85)",
                    transition: "all 0.5s cubic-bezier(0.23,1,0.32,1)",
                  }}>
                    <GlassIcon
                      name={step.icon}
                      size={56}
                      accent={step.accent}
                      shape="octagon"
                      glow={isActive}
                    />
                  </div>

                  <div style={{
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontWeight: 700, fontSize: "0.85rem",
                    color: isActive ? (step.accent === "gold" ? "#fbbf24" : "#fff") : "rgba(255,255,255,0.3)",
                    textAlign: "center", marginBottom: "0.375rem",
                    transition: "color 0.5s",
                  }}>
                    {step.label}
                  </div>
                  <div style={{
                    fontFamily: "'Inter', sans-serif", fontSize: "0.7rem",
                    color: isActive ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.15)",
                    textAlign: "center", lineHeight: 1.4,
                    transition: "color 0.5s",
                  }}>
                    {step.desc}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

