// OctagonRon Network — Chapter 04: Earn
// Trading terminal income simulator + Partner Dashboard Preview
import { useEffect, useRef, useState, useCallback } from "react";
import { GlassIcon } from "./Icons";

function useCountUp(target: number, duration = 1200, active = false) {
  const [value, setValue] = useState(0);
  const rafRef = useRef<number>(0);
  const startRef = useRef<number>(0);
  const startValRef = useRef(0);

  useEffect(() => {
    if (!active) return;
    cancelAnimationFrame(rafRef.current);
    startRef.current = performance.now();
    startValRef.current = value;

    const animate = (now: number) => {
      const elapsed = now - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(startValRef.current + (target - startValRef.current) * ease));
      if (progress < 1) rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, active, duration]);

  return value;
}

const COMMISSION_RATES = [0.15, 0.20, 0.25];
const PROJECT_VALUES = [500, 1000, 2000];
const REFERRAL_COUNTS = [1, 5, 10, 20, 50];

export default function ChapterEarn() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [referrals, setReferrals] = useState(2); // index
  const [projectVal, setProjectVal] = useState(1); // index
  const [commission, setCommission] = useState(1); // index

  const monthly = REFERRAL_COUNTS[referrals] * PROJECT_VALUES[projectVal] * COMMISSION_RATES[commission];
  const quarterly = monthly * 3;
  const annual = monthly * 12;
  const lifetime = annual * 5;

  const monthlyDisplay = useCountUp(monthly, 900, visible);
  const quarterlyDisplay = useCountUp(quarterly, 1100, visible);
  const annualDisplay = useCountUp(annual, 1300, visible);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const formatMoney = (n: number) => "$" + n.toLocaleString();

  return (
    <section
      id="earn"
      style={{
        padding: "8rem 0",
        background: "linear-gradient(180deg, #080a0f 0%, #060810 100%)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Ambient */}
      <div style={{
        position: "absolute", top: "30%", right: "-10%",
        width: "500px", height: "500px",
        background: "radial-gradient(circle, rgba(0,212,255,0.06) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        {/* Chapter label */}
        <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1.5rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
          <span className="chapter-label">04 — Earn</span>
          <div style={{ height: "1px", flex: 1, maxWidth: "80px", background: "linear-gradient(90deg, #fbbf24, transparent)" }} />
        </div>

        <h2 style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontSize: "clamp(2.5rem, 5vw, 4rem)",
          fontWeight: 700,
          color: "#fff",
          marginBottom: "0.75rem",
          lineHeight: 1.1,
          opacity: visible ? 1 : 0,
          transform: visible ? "none" : "translateY(30px)",
          transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
        }}>
          Your Earnings.<br />
          <span className="gradient-text-gold">Live.</span>
        </h2>

        <p style={{
          color: "rgba(255,255,255,0.5)",
          fontSize: "1rem",
          marginBottom: "3.5rem",
          opacity: visible ? 1 : 0,
          transition: "opacity 0.8s 0.2s",
        }}>
          Drag the sliders. Watch your income materialize in real time.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2rem", alignItems: "start" }}>
          {/* Left: Controls */}
          <div
            className="terminal"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "none" : "translateX(-30px)",
              transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.3s",
            }}
          >
            <div className="terminal-header">
              <div className="terminal-dot" style={{ background: "#ff5f57" }} />
              <div className="terminal-dot" style={{ background: "#ffbd2e" }} />
              <div className="terminal-dot" style={{ background: "#28c840" }} />
              <span style={{ marginLeft: "0.5rem", color: "rgba(0,212,255,0.6)", fontSize: "0.75rem" }}>income_simulator.exe</span>
            </div>

            <div style={{ padding: "2rem" }}>
              {/* Referrals slider */}
              <div style={{ marginBottom: "2rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.75rem" }}>
                  <label style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.8rem", fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.1em" }}>
                    BUSINESSES REFERRED / MONTH
                  </label>
                  <span style={{ color: "#00d4ff", fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "1rem" }}>
                    {REFERRAL_COUNTS[referrals]}
                  </span>
                </div>
                <input
                  type="range" min={0} max={4} step={1} value={referrals}
                  onChange={e => setReferrals(Number(e.target.value))}
                  style={{
                    width: "100%", height: "4px",
                    background: `linear-gradient(90deg, #00d4ff ${referrals * 25}%, rgba(255,255,255,0.1) ${referrals * 25}%)`,
                    borderRadius: "2px", outline: "none", border: "none",
                    WebkitAppearance: "none", cursor: "none",
                  }}
                />
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
                  {REFERRAL_COUNTS.map(v => (
                    <span key={v} style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.7rem", fontFamily: "'JetBrains Mono', monospace" }}>{v}</span>
                  ))}
                </div>
              </div>

              {/* Project value */}
              <div style={{ marginBottom: "2rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.75rem" }}>
                  <label style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.8rem", fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.1em" }}>
                    AVG PROJECT VALUE
                  </label>
                  <span style={{ color: "#8b5cf6", fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "1rem" }}>
                    {formatMoney(PROJECT_VALUES[projectVal])}
                  </span>
                </div>
                <input
                  type="range" min={0} max={2} step={1} value={projectVal}
                  onChange={e => setProjectVal(Number(e.target.value))}
                  style={{
                    width: "100%", height: "4px",
                    background: `linear-gradient(90deg, #8b5cf6 ${projectVal * 50}%, rgba(255,255,255,0.1) ${projectVal * 50}%)`,
                    borderRadius: "2px", outline: "none", border: "none",
                    WebkitAppearance: "none", cursor: "none",
                  }}
                />
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
                  {PROJECT_VALUES.map(v => (
                    <span key={v} style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.7rem", fontFamily: "'JetBrains Mono', monospace" }}>${v}</span>
                  ))}
                </div>
              </div>

              {/* Commission */}
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.75rem" }}>
                  <label style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.8rem", fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.1em" }}>
                    COMMISSION RATE
                  </label>
                  <span style={{ color: "#fbbf24", fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "1rem" }}>
                    {(COMMISSION_RATES[commission] * 100).toFixed(0)}%
                  </span>
                </div>
                <input
                  type="range" min={0} max={2} step={1} value={commission}
                  onChange={e => setCommission(Number(e.target.value))}
                  style={{
                    width: "100%", height: "4px",
                    background: `linear-gradient(90deg, #fbbf24 ${commission * 50}%, rgba(255,255,255,0.1) ${commission * 50}%)`,
                    borderRadius: "2px", outline: "none", border: "none",
                    WebkitAppearance: "none", cursor: "none",
                  }}
                />
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
                  {COMMISSION_RATES.map(v => (
                    <span key={v} style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.7rem", fontFamily: "'JetBrains Mono', monospace" }}>{(v*100).toFixed(0)}%</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Results */}
          <div style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "none" : "translateX(30px)",
            transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.4s",
          }}>
            {/* Main monthly */}
            <div style={{
              background: "linear-gradient(135deg, rgba(0,212,255,0.08) 0%, rgba(139,92,246,0.08) 100%)",
              border: "1px solid rgba(0,212,255,0.25)",
              clipPath: "polygon(16px 0%, calc(100% - 16px) 0%, 100% 16px, 100% calc(100% - 16px), calc(100% - 16px) 100%, 16px 100%, 0% calc(100% - 16px), 0% 16px)",
              padding: "2.5rem",
              marginBottom: "1rem",
              textAlign: "center",
              boxShadow: "0 0 40px rgba(0,212,255,0.1)",
            }}>
              <div style={{ color: "rgba(255,255,255,0.4)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "0.75rem" }}>
                ESTIMATED MONTHLY
              </div>
              <div style={{
                fontFamily: "'Space Grotesk', sans-serif",
                fontSize: "clamp(3rem, 6vw, 4.5rem)",
                fontWeight: 700,
                background: "linear-gradient(135deg, #00d4ff, #8b5cf6)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                lineHeight: 1,
                marginBottom: "0.5rem",
              }}>
                {formatMoney(monthlyDisplay)}
              </div>
              <div style={{ color: "rgba(255,255,255,0.3)", fontSize: "0.8rem" }}>
                {REFERRAL_COUNTS[referrals]} referrals × {formatMoney(PROJECT_VALUES[projectVal])} × {(COMMISSION_RATES[commission]*100).toFixed(0)}%
              </div>
            </div>

            {/* Secondary metrics */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem", marginBottom: "1rem" }}>
              {[
                { label: "Quarterly", value: formatMoney(quarterlyDisplay), color: "#8b5cf6" },
                { label: "Annual", value: formatMoney(annualDisplay), color: "#fbbf24" },
              ].map(m => (
                <div key={m.label} className="glass" style={{ borderRadius: "0.875rem", padding: "1.25rem", textAlign: "center" }}>
                  <div style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.15em", marginBottom: "0.5rem" }}>
                    {m.label.toUpperCase()}
                  </div>
                  <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "1.5rem", fontWeight: 700, color: m.color }}>
                    {m.value}
                  </div>
                </div>
              ))}
            </div>

            {/* Lifetime */}
            <div style={{
              background: "rgba(251,191,36,0.05)",
              border: "1px solid rgba(251,191,36,0.2)",
              borderRadius: "0.875rem",
              padding: "1.25rem",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}>
              <div>
                <div style={{ color: "rgba(255,255,255,0.4)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.15em" }}>5-YEAR POTENTIAL</div>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "1.75rem", fontWeight: 700, color: "#fbbf24" }}>
                  {formatMoney(lifetime)}
                </div>
              </div>
              <GlassIcon name="rocket" size={44} accent="gold" shape="octagon" glow />
            </div>
          </div>
        </div>

        {/* Partner Dashboard Preview */}
        <div style={{
          marginTop: "5rem",
          opacity: visible ? 1 : 0,
          transform: visible ? "none" : "translateY(40px)",
          transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.6s",
        }}>
          <div style={{ textAlign: "center", marginBottom: "2rem" }}>
            <p style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "0.5rem" }}>
              PARTNER DASHBOARD PREVIEW
            </p>
            <h3 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "1.75rem", color: "#fff", fontWeight: 700 }}>
              Your Command Center
            </h3>
          </div>

          <div className="terminal" style={{ maxWidth: "900px", margin: "0 auto" }}>
            <div className="terminal-header">
              <div className="terminal-dot" style={{ background: "#ff5f57" }} />
              <div className="terminal-dot" style={{ background: "#ffbd2e" }} />
              <div className="terminal-dot" style={{ background: "#28c840" }} />
              <span style={{ marginLeft: "0.5rem", color: "rgba(0,212,255,0.6)", fontSize: "0.75rem" }}>partner_dashboard — OctagonRon Network</span>
              <div style={{ marginLeft: "auto", display: "flex", gap: "0.5rem", alignItems: "center" }}>
                <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#28c840", boxShadow: "0 0 6px #28c840" }} />
                <span style={{ color: "rgba(255,255,255,0.3)", fontSize: "0.7rem", fontFamily: "'JetBrains Mono', monospace" }}>LIVE</span>
              </div>
            </div>

            <div style={{ padding: "1.5rem", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1rem", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
              {([
                { label: "Today's Referrals", value: "12", iconName: "mail"         as const, accent: "cyan"    as const, color: "#00d4ff" },
                { label: "Pending",           value: "5",  iconName: "clock"        as const, accent: "gold"    as const, color: "#fbbf24" },
                { label: "Closed",            value: "7",  iconName: "check-circle" as const, accent: "neutral" as const, color: "rgba(255,255,255,0.7)" },
                { label: "Commission",        value: "$2,640", iconName: "dollar"   as const, accent: "violet"  as const, color: "#8b5cf6" },
              ] as const).map(stat => (
                <div key={stat.label} style={{
                  background: "rgba(255,255,255,0.03)",
                  backdropFilter: "blur(12px)",
                  border: "1px solid rgba(255,255,255,0.06)",
                  borderRadius: "0.75rem",
                  padding: "1rem",
                }}>
                  <div style={{ marginBottom: "0.625rem" }}>
                    <GlassIcon name={stat.iconName} size={32} accent={stat.accent} shape="rounded" glow={false} />
                  </div>
                  <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "1.5rem", color: stat.color, marginBottom: "0.25rem" }}>
                    {stat.value}
                  </div>
                  <div style={{ color: "rgba(255,255,255,0.35)", fontSize: "0.7rem", fontFamily: "'Inter', sans-serif" }}>{stat.label}</div>
                </div>
              ))}
            </div>

            <div style={{ padding: "1.5rem", display: "grid", gridTemplateColumns: "2fr 1fr", gap: "1.5rem" }}>
              {/* Activity feed */}
              <div>
                <div style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.15em", marginBottom: "1rem" }}>
                  LIVE ACTIVITY
                </div>
                {[
                  { time: "2m ago", event: "Referral submitted", client: "Mike's Auto Shop", status: "pending", color: "#fbbf24" },
                  { time: "18m ago", event: "Proposal sent", client: "Green Valley Dental", status: "proposal", color: "#00d4ff" },
                  { time: "1h ago", event: "Project started", client: "Summit Law Group", status: "active", color: "#00d4ff" },
                  { time: "3h ago", event: "Commission released", client: "Bella's Restaurant", status: "paid", color: "#8b5cf6" },
                ].map((item, i) => (
                  <div key={i} style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.875rem",
                    padding: "0.625rem 0",
                    borderBottom: "1px solid rgba(255,255,255,0.04)",
                  }}>
                    <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: item.color, flexShrink: 0, boxShadow: `0 0 6px ${item.color}` }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8rem", color: "rgba(255,255,255,0.75)" }}>{item.event} — <span style={{ color: item.color }}>{item.client}</span></div>
                    </div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem", color: "rgba(255,255,255,0.25)" }}>{item.time}</div>
                  </div>
                ))}
              </div>

              {/* Notifications */}
              <div>
                <div style={{ color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.15em", marginBottom: "1rem" }}>
                  NOTIFICATIONS
                </div>
                {[
                  { msg: "Commission of $400 released!", color: "#fbbf24" },
                  { msg: "New referral accepted", color: "#00d4ff" },
                  { msg: "Proposal viewed by client", color: "#8b5cf6" },
                ].map((n, i) => (
                  <div key={i} style={{
                    padding: "0.625rem 0.875rem",
                    marginBottom: "0.5rem",
                    background: `${n.color}10`,
                    border: `1px solid ${n.color}25`,
                    borderRadius: "0.5rem",
                    fontSize: "0.75rem",
                    color: "rgba(255,255,255,0.65)",
                    fontFamily: "'Inter', sans-serif",
                    borderLeft: `3px solid ${n.color}`,
                  }}>
                    {n.msg}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
