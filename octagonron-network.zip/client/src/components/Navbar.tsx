// OctagonRon Network — Navigation bar
import { useState, useEffect } from "react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 500,
        transition: "all 0.4s cubic-bezier(0.23,1,0.32,1)",
        background: scrolled ? "rgba(8,10,15,0.9)" : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none",
      }}
    >
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "1.25rem 3rem" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <div
            className="octagon"
            style={{
              width: "36px",
              height: "36px",
              background: "linear-gradient(135deg, #00d4ff, #8b5cf6)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "11px", color: "#080a0f" }}>OR</span>
          </div>
          <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "#fff", letterSpacing: "-0.02em" }}>
            OctagonRon
          </span>
        </div>

        {/* Desktop nav */}
        <div style={{ display: "flex", alignItems: "center", gap: "2.5rem" }} className="hidden md:flex">
          {[
            { label: "How It Works", id: "how-it-works" },
            { label: "Earn", id: "earn" },
            { label: "Services", id: "services" },
            { label: "Partners", id: "leaderboard" },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              style={{
                background: "none",
                border: "none",
                color: "rgba(255,255,255,0.65)",
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.9rem",
                fontWeight: 500,
                transition: "color 0.2s",
                padding: 0,
              }}
              onMouseEnter={e => (e.currentTarget.style.color = "#00d4ff")}
              onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.65)")}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* CTA */}
        <button
          className="btn-primary hidden md:block"
          onClick={() => scrollTo("final-cta")}
          style={{ fontSize: "0.875rem", padding: "0.625rem 1.5rem" }}
        >
          Join the Network
        </button>

        {/* Mobile menu button */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          style={{ background: "none", border: "none", color: "#fff", display: "flex", flexDirection: "column", gap: "5px", padding: "4px" }}
          className="md:hidden"
        >
          {[0,1,2].map(i => (
            <span key={i} style={{ display: "block", width: "22px", height: "2px", background: "#00d4ff", borderRadius: "1px", transition: "all 0.3s" }} />
          ))}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{ background: "rgba(8,10,15,0.97)", borderTop: "1px solid rgba(255,255,255,0.06)", padding: "1.5rem 2rem" }}>
          {[
            { label: "How It Works", id: "how-it-works" },
            { label: "Earn", id: "earn" },
            { label: "Services", id: "services" },
            { label: "Partners", id: "leaderboard" },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              style={{ display: "block", width: "100%", textAlign: "left", background: "none", border: "none", color: "rgba(255,255,255,0.8)", fontFamily: "'Inter', sans-serif", fontSize: "1rem", padding: "0.75rem 0", borderBottom: "1px solid rgba(255,255,255,0.06)" }}
            >
              {item.label}
            </button>
          ))}
          <button className="btn-primary" style={{ marginTop: "1rem", width: "100%" }} onClick={() => scrollTo("final-cta")}>
            Join the Network
          </button>
        </div>
      )}
    </nav>
  );
}

