// OctagonRon Network — Chapter 03: Refer
// Professional SVG glass icons for AI workers and process steps
import { useEffect, useRef, useState } from "react";
import { GlassIcon, SvgIcon } from "./Icons";
import type { IconName } from "./Icons";

const AI_WORKERS: { icon: IconName; role: string; task: string; accent: "cyan" | "violet" }[] = [
  { icon: "bot",          role: "AI Receptionist",  task: "Answers phones 24/7",       accent: "cyan"   },
  { icon: "globe",        role: "Web Developer",    task: "Builds stunning websites",  accent: "violet" },
  { icon: "mail",         role: "Email Automation", task: "Sends follow-ups",          accent: "cyan"   },
  { icon: "calendar",     role: "Booking Agent",    task: "Books appointments",        accent: "violet" },
  { icon: "target",       role: "Lead Generator",   task: "Finds new clients",         accent: "cyan"   },
  { icon: "database",     role: "CRM Manager",      task: "Tracks every lead",         accent: "violet" },
];

const STEPS: { label: string; icon: IconName; accent: "cyan" | "violet" | "gold" }[] = [
  { label: "You Make the Introduction", icon: "handshake", accent: "cyan"   },
  { label: "OctagonRon Takes Over",     icon: "layers",    accent: "violet" },
  { label: "Our Team Does the Work",    icon: "zap",       accent: "cyan"   },
  { label: "You Collect the Commission",icon: "dollar",    accent: "gold"   },
];

export default function ChapterRefer() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [activeStep, setActiveStep] = useState(-1);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          STEPS.forEach((_, i) => {
            setTimeout(() => setActiveStep(i), 600 + i * 500);
          });
        }
      },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const getColor = (accent: string) =>
    accent === "cyan" ? "#00d4ff" : accent === "violet" ? "#8b5cf6" : "#fbbf24";

  return (
    <section
      style={{
        padding: "8rem 0",
        background: "#080a0f",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{
        position: "absolute", top: "50%", left: "50%",
        transform: "translate(-50%,-50%)",
        width: "600px", height: "600px",
        background: "radial-gradient(circle, rgba(139,92,246,0.06) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1.5rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
          <span className="chapter-label">03 — Refer</span>
          <div style={{ height: "1px", width: "60px", background: "linear-gradient(90deg, #8b5cf6, transparent)" }} />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "start" }}>
          {/* Left: Process steps */}
          <div>
            <h2 style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2rem, 4vw, 3.5rem)",
              fontWeight: 700, color: "#fff", marginBottom: "1rem",
              lineHeight: 1.05, letterSpacing: "-0.02em",
              opacity: visible ? 1 : 0,
              transform: visible ? "none" : "translateY(30px)",
              transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
            }}>
              You're the<br />
              <span style={{ color: "#00d4ff" }}>Connector.</span><br />
              We Do the Rest.
            </h2>

            <p style={{
              color: "rgba(255,255,255,0.5)", fontSize: "1rem", lineHeight: 1.7, marginBottom: "3rem",
              opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.2s",
            }}>
              One introduction triggers an entire ecosystem. Our team of developers, AI agents, designers, and automations branch out — handling every detail while you earn.
            </p>

            <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
              {STEPS.map((step, i) => {
                const color = getColor(step.accent);
                const isActive = activeStep >= i;
                return (
                  <div
                    key={step.label}
                    style={{
                      display: "flex", alignItems: "center", gap: "1.25rem",
                      padding: "1.125rem 1.5rem",
                      clipPath: "polygon(8px 0%, calc(100% - 8px) 0%, 100% 8px, 100% calc(100% - 8px), calc(100% - 8px) 100%, 8px 100%, 0% calc(100% - 8px), 0% 8px)",
                      background: isActive ? `${color}0d` : "transparent",
                      border: `1px solid ${isActive ? color + "40" : "transparent"}`,
                      backdropFilter: isActive ? "blur(10px)" : "none",
                      transition: "all 0.5s cubic-bezier(0.23,1,0.32,1)",
                      opacity: visible ? 1 : 0,
                      transform: visible ? "none" : "translateX(-20px)",
                    }}
                  >
                    <GlassIcon
                      name={step.icon}
                      size={44}
                      accent={step.accent as "cyan" | "violet" | "gold"}
                      shape="octagon"
                      glow={isActive}
                    />
                    <div style={{
                      fontFamily: "'Space Grotesk', sans-serif",
                      fontWeight: 600, fontSize: "0.95rem",
                      color: isActive ? "#fff" : "rgba(255,255,255,0.3)",
                      transition: "color 0.5s",
                    }}>
                      {step.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: AI Workers */}
          <div>
            <div style={{ opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.3s", marginBottom: "1.5rem" }}>
              <p style={{ color: "rgba(255,255,255,0.3)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.2em", marginBottom: "0.75rem" }}>
                OCTAGONRON DEPLOYS
              </p>
              <h3 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "1.5rem", color: "#fff", fontWeight: 700 }}>
                An Entire Army
              </h3>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.875rem" }}>
              {AI_WORKERS.map((worker, i) => {
                const color = getColor(worker.accent);
                return (
                  <div
                    key={worker.role}
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      backdropFilter: "blur(16px)",
                      WebkitBackdropFilter: "blur(16px)",
                      border: `1px solid ${color}20`,
                      clipPath: "polygon(8px 0%, calc(100% - 8px) 0%, 100% 8px, 100% calc(100% - 8px), calc(100% - 8px) 100%, 8px 100%, 0% calc(100% - 8px), 0% 8px)",
                      padding: "1.25rem",
                      opacity: visible ? 1 : 0,
                      transform: visible ? "none" : "translateY(20px) scale(0.95)",
                      transition: `all 0.6s cubic-bezier(0.23,1,0.32,1) ${0.4 + i * 0.1}s`,
                      position: "relative",
                    }}
                  >
                    {/* Active indicator octagon */}
                    <div style={{
                      position: "absolute", top: "0.75rem", right: "0.75rem",
                      width: "8px", height: "8px",
                      clipPath: "polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)",
                      background: color,
                      boxShadow: `0 0 8px ${color}`,
                    }} />

                    <div style={{ marginBottom: "0.75rem" }}>
                      <GlassIcon name={worker.icon} size={40} accent={worker.accent} shape="rounded" glow={false} />
                    </div>
                    <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 600, fontSize: "0.8rem", color, marginBottom: "0.25rem" }}>
                      {worker.role}
                    </div>
                    <div style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.4)", fontFamily: "'Inter', sans-serif" }}>
                      {worker.task}
                    </div>
                  </div>
                );
              })}
            </div>

            <div style={{
              marginTop: "1.5rem", padding: "1rem 1.25rem",
              background: "rgba(0,212,255,0.04)",
              border: "1px solid rgba(0,212,255,0.15)",
              backdropFilter: "blur(10px)",
              clipPath: "polygon(8px 0%, calc(100% - 8px) 0%, 100% 8px, 100% calc(100% - 8px), calc(100% - 8px) 100%, 8px 100%, 0% calc(100% - 8px), 0% 8px)",
              opacity: visible ? 1 : 0, transition: "opacity 0.8s 1.2s",
            }}>
              <p style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.8rem", color: "rgba(0,212,255,0.7)", lineHeight: 1.6 }}>
                <span style={{ color: "#00d4ff" }}>$ </span>They all work simultaneously.<br />
                <span style={{ color: "#8b5cf6" }}>→ </span>"This company has an army."
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

