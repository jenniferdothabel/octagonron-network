// OctagonRon Network — Chapter 02: Discover
// Professional SVG glass icons for business categories
import { useEffect, useRef, useState } from "react";
import { GlassIcon } from "./Icons";
import type { IconName } from "./Icons";

const BUSINESSES: { icon: IconName; name: string }[] = [
  { icon: "pizza",        name: "Restaurants"   },
  { icon: "wrench",       name: "Roofers"       },
  { icon: "wrench",       name: "Plumbers"      },
  { icon: "tooth",        name: "Dentists"      },
  { icon: "scale",        name: "Law Firms"     },
  { icon: "construction", name: "Construction"  },
  { icon: "hospital",     name: "Medical"       },
  { icon: "car",          name: "Auto Repair"   },
  { icon: "home",         name: "Real Estate"   },
  { icon: "building",     name: "Corporations"  },
];

export default function ChapterDiscover() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);
  const [activeCard, setActiveCard] = useState<number | null>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef as React.RefObject<HTMLElement>}
      id="how-it-works"
      style={{
        padding: "8rem 0",
        background: "linear-gradient(180deg, #080a0f 0%, #0a0d16 50%, #080a0f 100%)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "linear-gradient(rgba(0,212,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,0.025) 1px, transparent 1px)",
        backgroundSize: "60px 60px",
        pointerEvents: "none",
      }} />
      <div style={{
        position: "absolute", left: "-10%", top: "30%",
        width: "500px", height: "500px",
        background: "radial-gradient(circle, rgba(0,212,255,0.07) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr 1.4fr",
        gap: "0",
        maxWidth: "1280px",
        margin: "0 auto",
        padding: "0 3rem",
        alignItems: "center",
        position: "relative",
        zIndex: 1,
      }}>
        {/* Left: editorial */}
        <div style={{ paddingRight: "4rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "2rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s" }}>
            <span className="chapter-label">02 — Discover</span>
            <div style={{ height: "1px", width: "60px", background: "linear-gradient(90deg, #00d4ff, transparent)" }} />
          </div>

          <h2 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: "clamp(2.75rem, 5vw, 4.5rem)",
            fontWeight: 700, color: "#fff", lineHeight: 1.0, letterSpacing: "-0.03em",
            marginBottom: "1.5rem",
            opacity: visible ? 1 : 0,
            transform: visible ? "none" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
          }}>
            Every Business<br />
            <span style={{ color: "#00d4ff" }}>Needs What</span><br />
            We Build.
          </h2>

          <p style={{
            color: "rgba(255,255,255,0.5)", fontSize: "1.05rem", lineHeight: 1.75, marginBottom: "2.5rem",
            opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.2s",
          }}>
            From restaurants to law firms — every business owner you know is a potential connection. You don't need to sell. You just need to introduce.
          </p>

          <div style={{
            display: "inline-flex", alignItems: "center", gap: "1.25rem",
            padding: "1.25rem 1.75rem",
            background: "rgba(0,212,255,0.06)",
            backdropFilter: "blur(12px)",
            border: "1px solid rgba(0,212,255,0.2)",
            clipPath: "polygon(8px 0%, calc(100% - 8px) 0%, 100% 8px, 100% calc(100% - 8px), calc(100% - 8px) 100%, 8px 100%, 0% calc(100% - 8px), 0% 8px)",
            opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.35s",
          }}>
            <GlassIcon name="building" size={48} accent="cyan" shape="octagon" />
            <div>
              <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "1rem", color: "#fff" }}>10+ Industries Served</div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "0.8rem", color: "rgba(255,255,255,0.4)" }}>Every business is a potential connection</div>
            </div>
          </div>

          <div style={{ marginTop: "3rem", opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.5s" }}>
            <p style={{ color: "rgba(255,255,255,0.25)", fontFamily: "'JetBrains Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.2em" }}>
              EVERY BUSINESS IS CONNECTED
            </p>
          </div>
        </div>

        {/* Right: Business card grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "0.625rem" }}>
          {BUSINESSES.map((biz, i) => {
            const isActive = activeCard === i;
            return (
              <div
                key={biz.name + i}
                onMouseEnter={() => setActiveCard(i)}
                onMouseLeave={() => setActiveCard(null)}
                style={{
                  background: isActive
                    ? "linear-gradient(135deg, rgba(0,212,255,0.10), rgba(139,92,246,0.06))"
                    : "rgba(255,255,255,0.03)",
                  backdropFilter: "blur(14px)",
                  WebkitBackdropFilter: "blur(14px)",
                  border: `1px solid ${isActive ? "rgba(0,212,255,0.40)" : "rgba(255,255,255,0.07)"}`,
                  clipPath: "polygon(8px 0%, calc(100% - 8px) 0%, 100% 8px, 100% calc(100% - 8px), calc(100% - 8px) 100%, 8px 100%, 0% calc(100% - 8px), 0% 8px)",
                  padding: "1.125rem 0.5rem",
                  textAlign: "center",
                  opacity: visible ? 1 : 0,
                  transform: visible
                    ? isActive ? "translateY(-6px) scale(1.05)" : "translateY(0)"
                    : "translateY(30px)",
                  transition: `all 0.5s cubic-bezier(0.23,1,0.32,1) ${i * 0.05}s`,
                  cursor: "default",
                  boxShadow: isActive ? "0 0 20px rgba(0,212,255,0.15)" : "none",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "0.625rem",
                }}
              >
                <GlassIcon
                  name={biz.icon}
                  size={40}
                  accent={i % 2 === 0 ? "cyan" : "violet"}
                  shape="octagon"
                  glow={isActive}
                />
                <div style={{
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 500, fontSize: "0.65rem",
                  color: isActive ? "#00d4ff" : "rgba(255,255,255,0.5)",
                  transition: "color 0.3s",
                  lineHeight: 1.3,
                }}>
                  {biz.name}
                </div>
                {isActive && (
                  <div style={{ fontSize: "0.55rem", color: "rgba(0,212,255,0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
                    ● LIVE
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

