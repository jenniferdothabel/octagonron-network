// OctagonRon Network — Footer
export default function Footer() {
  return (
    <footer style={{
      background: "#040508",
      borderTop: "1px solid rgba(255,255,255,0.06)",
      padding: "3rem 0",
    }}>
      <div className="container" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1.5rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <div
            className="octagon"
            style={{
              width: "32px", height: "32px",
              background: "linear-gradient(135deg, #00d4ff, #8b5cf6)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
          >
            <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "10px", color: "#080a0f" }}>OR</span>
          </div>
          <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "1rem", color: "#fff" }}>OctagonRon Network</span>
        </div>

        <div style={{ display: "flex", gap: "2rem" }}>
          {["Privacy", "Terms", "Contact"].map(link => (
            <a
              key={link}
              href="#"
              onClick={e => e.preventDefault()}
              style={{
                color: "rgba(255,255,255,0.35)",
                fontFamily: "'Inter', sans-serif",
                fontSize: "0.85rem",
                textDecoration: "none",
                transition: "color 0.2s",
              }}
              onMouseEnter={e => (e.currentTarget.style.color = "#00d4ff")}
              onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.35)")}
            >
              {link}
            </a>
          ))}
        </div>

        <p style={{ color: "rgba(255,255,255,0.2)", fontFamily: "'Inter', sans-serif", fontSize: "0.8rem" }}>
          © 2025 OctagonRon Network. All rights reserved.
        </p>
      </div>
    </footer>
  );
}

