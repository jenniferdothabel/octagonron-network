// OctagonRon Network — Glass leaderboard with SVG rank badges
import { useEffect, useRef, useState } from "react";
import { GlassIcon, SvgIcon } from "./Icons";

const PARTNERS = [
  { name: "Ashley", earnings: 8400, rank: 1 },
  { name: "Mike",   earnings: 6200, rank: 2 },
  { name: "Taylor", earnings: 5600, rank: 3 },
  { name: "Jordan", earnings: 4800, rank: 4 },
  { name: "Casey",  earnings: 3900, rank: 5 },
  { name: "Riley",  earnings: 3200, rank: 6 },
  { name: "Morgan", earnings: 2800, rank: 7 },
];

export default function Leaderboard() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.2 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="leaderboard"
      style={{
        padding: "8rem 0",
        background: "linear-gradient(180deg, #0a0d16 0%, #080a0f 100%)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{
        position: "absolute", top: "50%", left: "50%",
        transform: "translate(-50%,-50%)",
        width: "400px", height: "400px",
        background: "radial-gradient(circle, rgba(251,191,36,0.05) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div className="container" ref={sectionRef} style={{ position: "relative", zIndex: 1 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "center" }}>
          {/* Left: Copy */}
          <div>
            <p style={{
              color: "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono', monospace",
              fontSize: "0.75rem", letterSpacing: "0.2em", marginBottom: "1rem",
              opacity: visible ? 1 : 0, transition: "opacity 0.8s",
            }}>
              TOP PARTNERS
            </p>
            <h2 style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2.5rem, 4vw, 3.5rem)",
              fontWeight: 700, color: "#fff", lineHeight: 1.05, letterSpacing: "-0.02em",
              marginBottom: "1.5rem",
              opacity: visible ? 1 : 0,
              transform: visible ? "none" : "translateY(30px)",
              transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.1s",
            }}>
              The Network<br />
              <span style={{ color: "#fbbf24" }}>Rewards Results.</span>
            </h2>
            <p style={{
              color: "rgba(255,255,255,0.5)", fontSize: "1rem", lineHeight: 1.7,
              opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.2s",
            }}>
              Our top partners earn $5,000–$10,000+ per month through consistent introductions. No experience required. No ceiling on earnings.
            </p>

            <div style={{
              marginTop: "2.5rem", display: "flex", gap: "2.5rem",
              opacity: visible ? 1 : 0, transition: "opacity 0.8s 0.3s",
            }}>
              {[
                { label: "Avg. First Commission", value: "$400" },
                { label: "Top Partner Monthly",   value: "$8,400" },
              ].map(stat => (
                <div key={stat.label}>
                  <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "1.75rem", color: "#fbbf24" }}>{stat.value}</div>
                  <div style={{ color: "rgba(255,255,255,0.35)", fontSize: "0.8rem", fontFamily: "'Inter', sans-serif", marginTop: "0.25rem" }}>{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Leaderboard panel */}
          <div style={{
            background: "rgba(255,255,255,0.03)",
            backdropFilter: "blur(24px)",
            WebkitBackdropFilter: "blur(24px)",
            border: "1px solid rgba(255,255,255,0.08)",
            clipPath: "polygon(16px 0%, calc(100% - 16px) 0%, 100% 16px, 100% calc(100% - 16px), calc(100% - 16px) 100%, 16px 100%, 0% calc(100% - 16px), 0% 16px)",
            overflow: "hidden",
            opacity: visible ? 1 : 0,
            transform: visible ? "none" : "translateX(30px)",
            transition: "all 0.8s cubic-bezier(0.23,1,0.32,1) 0.3s",
          }}>
            {/* Header */}
            <div style={{
              padding: "1.25rem 1.5rem",
              borderBottom: "1px solid rgba(255,255,255,0.06)",
              display: "flex", justifyContent: "space-between", alignItems: "center",
              background: "rgba(251,191,36,0.04)",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                <GlassIcon name="award" size={32} accent="gold" shape="octagon" glow={false} />
                <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "#fff" }}>
                  Monthly Leaderboard
                </span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <div style={{
                  width: "7px", height: "7px",
                  clipPath: "polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)",
                  background: "#28c840", boxShadow: "0 0 6px #28c840",
                }} />
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem", color: "rgba(255,255,255,0.3)" }}>LIVE</span>
              </div>
            </div>

            {PARTNERS.map((partner, i) => (
              <div
                key={partner.name}
                style={{
                  display: "flex", alignItems: "center", gap: "1rem",
                  padding: "0.875rem 1.5rem",
                  borderBottom: i < PARTNERS.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                  background: partner.rank === 1 ? "rgba(251,191,36,0.06)" : "transparent",
                  opacity: visible ? 1 : 0,
                  transform: visible ? "none" : "translateX(20px)",
                  transition: `all 0.6s cubic-bezier(0.23,1,0.32,1) ${0.4 + i * 0.08}s`,
                }}
              >
                {/* Rank badge */}
                {partner.rank <= 3 ? (
                  <GlassIcon
                    name={partner.rank === 1 ? "star" : partner.rank === 2 ? "award" : "shield"}
                    size={34}
                    accent={partner.rank === 1 ? "gold" : "neutral"}
                    shape="octagon"
                    glow={partner.rank === 1 && visible}
                  />
                ) : (
                  <div style={{
                    width: "34px", height: "34px",
                    clipPath: "polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)",
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    flexShrink: 0,
                  }}>
                    <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "0.7rem", color: "rgba(255,255,255,0.4)" }}>
                      {partner.rank}
                    </span>
                  </div>
                )}

                <div style={{ flex: 1 }}>
                  <div style={{
                    fontFamily: "'Space Grotesk', sans-serif", fontWeight: 600, fontSize: "0.95rem",
                    color: partner.rank === 1 ? "#fbbf24" : "#fff",
                  }}>
                    {partner.name}
                  </div>
                </div>

                <div style={{
                  fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "0.9rem",
                  color: partner.rank === 1 ? "#fbbf24" : "rgba(255,255,255,0.6)",
                }}>
                  ${partner.earnings.toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
