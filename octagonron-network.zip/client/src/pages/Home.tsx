// OctagonRon Network — Main Home page
// Cinematic chapter-based experience: Connect → Discover → Refer → Earn
import { useEffect, useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import HeroCanvas from "@/components/HeroCanvas";
import ChapterDiscover from "@/components/ChapterDiscover";
import ChapterRefer from "@/components/ChapterRefer";
import ChapterEarn from "@/components/ChapterEarn";
import ServicesSection from "@/components/ServicesSection";
import WorldExpansion from "@/components/WorldExpansion";
import Testimonials from "@/components/Testimonials";
import ProcessTimeline from "@/components/ProcessTimeline";
import Leaderboard from "@/components/Leaderboard";
import WhyJoin from "@/components/WhyJoin";
import FinalCTA from "@/components/FinalCTA";
import Footer from "@/components/Footer";
import CustomCursor from "@/components/CustomCursor";
import ScrollProgress from "@/components/ScrollProgress";

function HeroSection() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 200);
    return () => clearTimeout(t);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      style={{
        position: "relative",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        overflow: "hidden",
        background: "#080a0f",
      }}
    >
      {/* Network canvas background */}
      <HeroCanvas />

      {/* Gradient overlay for text readability */}
      <div style={{
        position: "absolute",
        inset: 0,
        background: "linear-gradient(135deg, rgba(8,10,15,0.85) 0%, rgba(8,10,15,0.4) 50%, rgba(8,10,15,0.7) 100%)",
        pointerEvents: "none",
      }} />

      {/* Content */}
      <div className="container" style={{ position: "relative", zIndex: 10, paddingTop: "6rem", paddingBottom: "6rem" }}>
        <div style={{ maxWidth: "700px" }}>
          {/* Chapter label */}
          <div style={{
            display: "flex",
            alignItems: "center",
            gap: "1rem",
            marginBottom: "2rem",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "none" : "translateY(20px)",
            transition: "all 0.8s cubic-bezier(0.23,1,0.32,1)",
          }}>
            <span className="chapter-label">01 — Connect</span>
            <div style={{ height: "1px", width: "60px", background: "linear-gradient(90deg, #00d4ff, transparent)" }} />
          </div>

          {/* Main headline */}
          <h1 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: "clamp(3rem, 7vw, 6rem)",
            fontWeight: 700,
            color: "#fff",
            lineHeight: 1.05,
            letterSpacing: "-0.03em",
            marginBottom: "1.5rem",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "none" : "translateY(40px)",
            transition: "all 1s cubic-bezier(0.23,1,0.32,1) 0.1s",
          }}>
            Build Relationships.<br />
            <span className="gradient-text">Build Income.</span><br />
            Build the Network.
          </h1>

          {/* Subtext */}
          <p style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: "1.2rem",
            color: "rgba(255,255,255,0.6)",
            lineHeight: 1.7,
            maxWidth: "520px",
            marginBottom: "3rem",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "none" : "translateY(30px)",
            transition: "all 1s cubic-bezier(0.23,1,0.32,1) 0.25s",
          }}>
            Turn your network into income. Introduce business owners to technology that saves them time and makes them money. We handle the work. You earn the commission.
          </p>

          {/* Buttons */}
          <div style={{
            display: "flex",
            gap: "1rem",
            flexWrap: "wrap",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "none" : "translateY(20px)",
            transition: "all 1s cubic-bezier(0.23,1,0.32,1) 0.4s",
          }}>
            <button
              className="btn-primary"
              onClick={() => scrollTo("final-cta")}
            >
              Become a Partner
            </button>
            <button
              className="btn-ghost"
              onClick={() => scrollTo("how-it-works")}
            >
              ▶ Watch 90 Second Overview
            </button>
          </div>

          {/* Stats */}
          <div style={{
            display: "flex",
            gap: "3rem",
            marginTop: "4rem",
            opacity: loaded ? 1 : 0,
            transition: "opacity 1s 0.6s",
          }}>
            {[
              { value: "15–25%", label: "Commission Rate" },
              { value: "$400+", label: "Avg First Commission" },
              { value: "7", label: "Services to Refer" },
            ].map(stat => (
              <div key={stat.label}>
                <div style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontWeight: 700,
                  fontSize: "1.5rem",
                  color: "#00d4ff",
                }}>
                  {stat.value}
                </div>
                <div style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "0.8rem",
                  color: "rgba(255,255,255,0.4)",
                  marginTop: "0.25rem",
                }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div style={{
        position: "absolute",
        bottom: "2.5rem",
        left: "50%",
        transform: "translateX(-50%)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "0.5rem",
        opacity: loaded ? 0.5 : 0,
        transition: "opacity 1s 1s",
        animation: "float 3s ease-in-out infinite",
      }}>
        <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem", color: "rgba(255,255,255,0.4)", letterSpacing: "0.2em" }}>SCROLL</span>
        <div style={{ width: "1px", height: "40px", background: "linear-gradient(180deg, rgba(0,212,255,0.6), transparent)" }} />
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <div style={{ background: "#080a0f", minHeight: "100vh" }}>
      <CustomCursor />
      <ScrollProgress />
      <Navbar />

      <HeroSection />
      <ChapterDiscover />
      <ChapterRefer />
      <ChapterEarn />
      <ServicesSection />
      <WorldExpansion />
      <Testimonials />
      <ProcessTimeline />
      <Leaderboard />
      <WhyJoin />
      <FinalCTA />
      <Footer />
    </div>
  );
}
